import streamlit as st
import qrcode
from PIL import Image
from io import BytesIO

# Function to generate QR code
def generate_qr_code(data):
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill='black', back_color='white')
    return img

# Convert PIL Image to bytes
def img_to_bytes(img):
    buf = BytesIO()
    img.save(buf, format="PNG")
    byte_im = buf.getvalue()
    return byte_im

# Streamlit app
st.title("QR Code Generator")

# Input field for the data to encode
data = st.text_input("Enter data to encode in QR code", "")

if data:
    # Generate QR code
    img = generate_qr_code(data)
    img_bytes = img_to_bytes(img)

    # Display QR code
    st.image(img_bytes, caption="Generated QR Code")

    # Provide download button for the QR code image
    st.download_button(
        label="Download QR Code",
        data=img_bytes,
        file_name="qr_code.png",
        mime="image/png"
    )
